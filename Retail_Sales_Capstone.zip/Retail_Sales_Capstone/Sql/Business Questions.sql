-----SQL Business Questions & Queries-----


--1. Total revenue in the last 12 months?
SELECT 
    SUM(total_amount) AS total_revenue
FROM 
    sales_data
WHERE 
    order_date >= DATEADD(MONTH, -12, GETDATE());

--2.Top 5 best-selling products by quantity?
SELECT TOP 5 
    p.product_name,
    SUM(s.quantity) AS total_quantity
FROM 
    sales_data s
JOIN 
    products p ON s.product_id = p.product_id
GROUP BY 
    p.product_name
ORDER BY 
    total_quantity DESC;

--3. Number of customers from each region?--
SELECT 
    region,
    COUNT(*) AS customer_count
FROM 
    customers
GROUP BY 
    region;

--4. Store with the highest profit in the past year?
SELECT TOP 1
    st.store_id,
    st.store_name,
    SUM(s.total_amount - (p.cost_price * s.quantity)) AS total_profit
FROM 
    sales_data s
JOIN 
    stores st ON s.store_id = st.store_id
JOIN 
    products p ON s.product_id = p.product_id
WHERE 
    s.order_date >= DATEADD(YEAR, -1, GETDATE())
GROUP BY 
    st.store_id, st.store_name
ORDER BY 
    total_profit DESC;


--5.Return rate by product category?--
SELECT 
    p.category,
    COUNT(r.return_id) * 1.0 / COUNT(s.order_id) AS return_rate
FROM 
    sales_data s
JOIN 
    products p ON s.product_id = p.product_id
LEFT JOIN 
    returns r ON s.order_id = r.order_id
GROUP BY 
    p.category;

--6. Average revenue per customer by age group?--
SELECT 
    c.age_group,
    AVG(s.total_amount) AS avg_revenue
FROM 
    sales_data s
JOIN 
    customers c ON s.customer_id = c.customer_id
GROUP BY 
    c.age_group;


--7. More profitable sales channel (Online vs In-Store)--
SELECT 
    sales_channel,
    AVG(s.total_amount - (p.cost_price * s.quantity)) AS avg_profit
FROM 
    sales_data s
JOIN 
    products p ON s.product_id = p.product_id
GROUP BY 
    sales_channel;


--8. Monthly profit trend by region for the last 2 years?

SELECT 
    FORMAT(s.order_date, 'yyyy-MM') AS month,
    st.region,
    SUM(s.total_amount - (p.cost_price * s.quantity)) AS total_profit
FROM 
    sales_data s
JOIN 
    stores st ON s.store_id = st.store_id
JOIN 
    products p ON s.product_id = p.product_id
WHERE 
    s.order_date >= DATEADD(YEAR, -2, GETDATE())
GROUP BY 
    FORMAT(s.order_date, 'yyyy-MM'), st.region
ORDER BY 
    month, st.region;

--9. Top 3 products with the highest return rate in each category?

WITH ProductReturnRates AS (
    SELECT 
        p.category,
        p.product_name,
        COUNT(r.return_id) * 1.0 / COUNT(s.order_id) AS return_rate
    FROM 
        sales_data s
    JOIN 
        products p ON s.product_id = p.product_id
    LEFT JOIN 
        returns r ON s.order_id = r.order_id
    GROUP BY 
        p.category, p.product_name
)

SELECT *
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY category ORDER BY return_rate DESC) AS rn
    FROM ProductReturnRates
) AS RankedProducts
WHERE rn <= 3;


--10. Top 5 customers by total profit and their tenure?--


SELECT TOP 5 
    c.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    SUM(s.total_amount - (p.cost_price * s.quantity)) AS total_profit,
    DATEDIFF(DAY, c.signup_date, GETDATE()) AS tenure_days
FROM 
    sales_data s
JOIN 
    customers c ON s.customer_id = c.customer_id
JOIN 
    products p ON s.product_id = p.product_id
GROUP BY 
    c.customer_id, c.first_name, c.last_name, c.signup_date
ORDER BY 
    total_profit DESC;

