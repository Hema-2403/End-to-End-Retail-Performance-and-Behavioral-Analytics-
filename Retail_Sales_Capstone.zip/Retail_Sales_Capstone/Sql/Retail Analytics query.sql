CREATE DATABASE RetailAnalytics;
GO

USE RetailAnalytics;
GO


-- Check duplicates in customers
SELECT customer_id, COUNT(*) AS cnt
FROM customers
GROUP BY customer_id
HAVING COUNT(*) > 1;

-- Check duplicates in products
SELECT product_id, COUNT(*) AS cnt
FROM products
GROUP BY product_id
HAVING COUNT(*) > 1;

-- Check duplicates in stores
SELECT store_id, COUNT(*) AS cnt
FROM stores
GROUP BY store_id
HAVING COUNT(*) > 1;

-- Check duplicates in sales_data
SELECT order_id, COUNT(*) AS cnt
FROM sales_data
GROUP BY order_id
HAVING COUNT(*) > 1;



ALTER TABLE customers
ADD CONSTRAINT pk_customers PRIMARY KEY (customer_id);

ALTER TABLE products
ADD CONSTRAINT pk_products PRIMARY KEY (product_id);

ALTER TABLE stores
ADD CONSTRAINT pk_stores PRIMARY KEY (store_id);

ALTER TABLE sales_data
ADD CONSTRAINT pk_sales_data PRIMARY KEY (order_id);

ALTER TABLE returns
ADD CONSTRAINT pk_returns PRIMARY KEY (return_id);

ALTER TABLE sales_data
ADD CONSTRAINT fk_sales_customer
FOREIGN KEY (customer_id) REFERENCES customers(customer_id);

ALTER TABLE sales_data
ADD CONSTRAINT fk_sales_product
FOREIGN KEY (product_id) REFERENCES products(product_id);

ALTER TABLE sales_data
ADD CONSTRAINT fk_sales_store
FOREIGN KEY (store_id) REFERENCES stores(store_id);

ALTER TABLE returns
ADD CONSTRAINT fk_returns_order
FOREIGN KEY (order_id) REFERENCES sales_data(order_id);




